﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoshanGharProject
{
    public partial class AddUpdateForm : Form
    {
        public AddUpdateForm()
        {
            InitializeComponent();
        }

        public string conString = "Data Source=NAUMANAKRAM\\SQLEXPRESS;" +
                                    "Initial Catalog = db_RoshanGharFinal; " +
                                    "Integrated Security = True";

        afterLoginForm af = new afterLoginForm();
        private void lstCust_MouseClick(object sender, MouseEventArgs e)
        {
            
            
        }
        private void listCust_Click(object sender, EventArgs e)
        {
            //txtCustomer.Text = listCust.SelectedItems[0].SubItems[0].Text;
            
        }

        private void AddUpdateForm_Load(object sender, EventArgs e)
        {
            btnAdd.Hide();
            gpCustomer.Hide();
            listViewCustomer();
        }
        public void listViewCustomer()
        {
            listCust.Columns.Clear();
            listCust.Columns.Add("ID", 75);
            listCust.Columns.Add("Customer Name", 100);
            listCust.Columns.Add("Address", 150);
            listCust.Columns.Add("Cnic", 150);
            listCust.Columns.Add("Account Id", 75);

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listCust.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from customer", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetString(2).ToString());
                lv.SubItems.Add(rd.GetString(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                listCust.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            af.Show();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            gpCustomer.Show();
            gpCustomer.Text = "Update Record!";
            
            
        }
        
        private void listCust_MouseClick(object sender, MouseEventArgs e)
        {
            txtID.Text=listCust.SelectedItems[0].SubItems[0].Text;
            string lname = listCust.SelectedItems[0].SubItems[1].Text;
            txtCustomer.Text = lname;
            txtAddress.Text = listCust.SelectedItems[0].SubItems[2].Text;
            txtCnic.Text = listCust.SelectedItems[0].SubItems[3].Text;
            txtAcc.Text = listCust.SelectedItems[0].SubItems[4].Text;
        }
       

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "update customer set Name ='" + txtCustomer.Text + "'," +
                "address ='" + txtAddress.Text + "'," +
                "cnic = '" + txtCnic.Text + "'" +
                "where c_id = '" + txtID.Text + "'";
            cmd.ExecuteNonQuery();
            con.Close();
            listViewCustomer();
        }
    }
}
