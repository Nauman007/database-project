﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoshanGharProject
{
    public partial class LoginForm : Form
    {
        public string conString = "Data Source=NAUMANAKRAM\\SQLEXPRESS;" +
                                      "Initial Catalog = db_RoshanGharFinal; " +
                                      "Integrated Security = True";
        public LoginForm()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtusername.Text == "" || txtpassword.Text == "")
                MessageBox.Show("Fields cannot be empty", "Error!",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            else
                UserAuthentication();
        }

        public void UserAuthentication()
        {

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            // SqlCommand cmd = new SqlCommand(, con");
            string query = "select count(*) from loginInfo where name = '"+txtusername.Text +"' and passcode ='" + txtpassword.Text +"'";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                this.Hide();
                afterLoginForm alf = new afterLoginForm();
                alf.Show();
               
            }
            else
            {
                lblMessage.Text = "incorrect username or password";
            }
        }

        

        private void LoginForm_Load(object sender, EventArgs e)
        {
            //txtpassword.UseSystemPasswordChar = true;
        }

        private void pictureBox2_MouseHover(object sender, EventArgs e)
        {
            txtpassword.UseSystemPasswordChar = false;
        }

        private void pictureBox2_MouseLeave(object sender, EventArgs e)
        {
            txtpassword.UseSystemPasswordChar = true;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

