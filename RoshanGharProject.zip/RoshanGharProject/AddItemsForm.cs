﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoshanGharProject
{
    public partial class AddItemsForm : Form
    {
        public string conString = "Data Source=NAUMANAKRAM\\SQLEXPRESS;" +
                                   "Initial Catalog = db_RoshanGharFinal; " +
                                   "Integrated Security = True";
        public AddItemsForm()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        //int y = 1;
        public void listViewStocksearch()
        {
            //listStock.Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
            //hjjjh

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listStock.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Stock where Comapany_Name like'" + txtSearchBox.Text + "%'", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());
                //lv.SubItems.Add(rd.GetString(8).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());
                lv.SubItems.Add(rd.GetInt32(10).ToString());
                //


                //   lv.SubItems.Add(rd.GetInt32(5).ToString());





                listStock.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        //int x = 1;
        public void listViewStock()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listStock.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from stock", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());
                //lv.SubItems.Add(rd.GetString(8).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());
                lv.SubItems.Add(rd.GetInt32(10).ToString());

                listStock.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }

        private void txtSearchBox_TextChanged(object sender, EventArgs e)
        {
            // listViewStock();
            listViewStocksearch();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            afterLoginForm a = new afterLoginForm();
            a.Show();
        }

        private void AddItemsForm_Load(object sender, EventArgs e)
        {
            pnlAdditems.Hide();
            listViewStock();
            //listViewStocksearch();
            //      listViewStock();
        }

        public void addItemsTolist()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            int price = Int32.Parse(txtPricePerUnit.Text);
            int qty = Int32.Parse(txtQuantity.Text);
            int total = price * qty;
            int salePrice = Int32.Parse(txtSale.Text);
            SqlCommand cmd = new SqlCommand("insert into stock values('" + txtCompanyName.Text + "'," + price + "," + total + "," + qty + ",2,'" + txtColor.Text + "','" + txtTYpe.Text + "',' ','" + txtWatt.Text + "'," + salePrice + ",'',0,0) ", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }
        string companyName;
        string pricePerunit;
        int prevquantity;
        string color;
        string type;
        string watt;
        string sale;
        int cust_id;
        void listviewToText()
        {
            if (listStock.SelectedItems.Count > 0)
            {
                txtCompanyName.Text = listStock.SelectedItems[0].SubItems[1].Text;
                txtPricePerUnit.Text = listStock.SelectedItems[0].SubItems[2].Text;
                txtQuantity.Text = listStock.SelectedItems[0].SubItems[3].Text;
                txtColor.Text = listStock.SelectedItems[0].SubItems[5].Text;
                txtTYpe.Text = listStock.SelectedItems[0].SubItems[6].Text;
                txtWatt.Text = listStock.SelectedItems[0].SubItems[7].Text;
                txtSale.Text = listStock.SelectedItems[0].SubItems[8].Text;
                cust_id = Int32.Parse(listStock.SelectedItems[0].SubItems[0].Text);

                companyName = txtCompanyName.Text;
                pricePerunit = txtPricePerUnit.Text;
                prevquantity = Int32.Parse(txtQuantity.Text);
                color = txtColor.Text;
                type = txtTYpe.Text;
                watt = txtWatt.Text;
                sale = txtSale.Text;
            }
            //MessageBox.Show(listStock.SelectedItems[0].SubItems[0].Text);

        }
        public void updateStock()
        {
            //MessageBox.Show(listStock.SelectedItems[0].SubItems[0].Text);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            int price = Int32.Parse(txtPricePerUnit.Text);
            int qty = Int32.Parse(txtQuantity.Text);
            prevquantity += qty;
            int total = price * prevquantity;
            int salePrice = Int32.Parse(txtSale.Text);
            SqlCommand cmd = new SqlCommand("update stock set comapany_name = '" + txtCompanyName.Text + "', original_price = " + price + ",total_price =" + total + " ,st_quantity = " + prevquantity + " ,color = '" + txtColor.Text + "', st_category = '" + txtTYpe.Text + "',watt = '" + txtWatt.Text + "',salesprice = '" + txtSale.Text + "' where st_id = " + cust_id + "", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }
        private void btnAddUpdate_Click(object sender, EventArgs e)
        {
            if (txtCompanyName.Text == "" ||
                txtColor.Text == "" ||
                txtTYpe.Text == "" ||
                txtWatt.Text == "")
            {
                MessageBox.Show("Fields Cannot be empty!", "Warning",
               MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                addItemsTolist();
                listViewStock();
                MessageBox.Show("New Items Added Successfully!", "Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            
        }

        private void listStock_Click(object sender, EventArgs e)
        {
            listviewToText();
        }

        private void btnUpdateList_Click(object sender, EventArgs e)
        {
            if (txtCompanyName.Text == "" ||
                txtColor.Text == "" ||
                txtTYpe.Text == "" ||
                txtWatt.Text == "")
            {
                MessageBox.Show("Fields Cannot be empty!", "Warning",
               MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                updateStock();
                listViewStock();
                MessageBox.Show("Records Update Successfully!", "Information",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            pnlAdditems.Text = "Add Items";
            makeFieldsEmpty();
            pnlAdditems.Show();
            btnUpdateList.Hide();
            btnAddUpdate.Show();

        }
        public void makeFieldsEmpty()
        {
            txtColor.Text = "";
            txtCompanyName.Text = "";
            txtPricePerUnit.Text = "0";
            txtQuantity.Text = "0";
            txtTYpe.Text = "";
            txtWatt.Text = "";
            txtSale.Text = "0";
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
                pnlAdditems.Text = "Update Items";
                makeFieldsEmpty();
                pnlAdditems.Show();
                btnUpdateList.Show();
                btnAddUpdate.Hide();
            
            
        }
    }
}
