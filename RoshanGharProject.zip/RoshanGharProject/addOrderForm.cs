﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoshanGharProject
{
    public partial class addOrderForm : Form
    {
        #region connectionString
        public string conString = "Data Source=NAUMANAKRAM\\SQLEXPRESS;" +
                                  "Initial Catalog = db_RoshanGharFinal; " +
                                  "Integrated Security = True";
        public addOrderForm()
        {
            InitializeComponent();
        }
        #endregion

        #region buttonClickEvents
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm lg = new LoginForm();
            lg.Show();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
            afterLoginForm ad = new afterLoginForm();
            ad.Show();
        }
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            if (txtQty.Text == "" ||
                cmbPName.Text == "" || cmbPrice.Text == "" ||
                cmbtype.Text == "" || cmbWatts.Text == "" ||
                cmbColor.Text == "")
                MessageBox.Show("O Bhai Kuch enter Krro gay tw calculate krun ga na kuch :D ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                int price = Int32.Parse(cmbPrice.Text);
                int qty = Int32.Parse(txtQty.Text);
                int total = price * qty;

                txtTotalBill.Text = total.ToString();
            }
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (Int32.Parse(listStock.SelectedItems[0].SubItems[4].Text) < Int32.Parse(txtQuantity.Text))
            {
                MessageBox.Show("No. of Items exceeds ... Items left in this stock " + listStock.SelectedItems[0].SubItems[4].Text + "\n\nYou Entered " + txtQuantity.Text, "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                

                int price = Int32.Parse(tempForSelectedItem);
                int qty = Int32.Parse(txtQuantity.Text);
                int total = price * qty;
                ListViewItem lv2 = new ListViewItem(txtQuantity.Text);
                lv2.SubItems.Add(total.ToString());
                listQty.Items.Add(lv2);
                grandtotal = Int32.Parse(txtgrandtotal.Text);
                grandtotal += total;
                txtgrandtotal.Text = grandtotal.ToString();
                pnlAddQty.Hide();
            }

        }
        void addToList()
        {
            if (txcust.Text == "")
            {
                MessageBox.Show("Please Select Customer Name to continue", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
               
            }
            
        }
        #endregion

        #region Methods
        int cust_id = 0;
        int acc_id = 0;
        int grandTotal = 0;
        int paidbill = 0;
        int duebill = 0;
        public void updateRecord(int total, int amtReceived)
        {
            if (lstCust.SelectedItems.Count > 0)
            {
                int temp = Int32.Parse(lstCust.SelectedItems[0].SubItems[0].Text);
                int tempAccID = Int32.Parse(lstCust.SelectedItems[0].SubItems[2].Text);
                int tempGrandTotal = Int32.Parse(lstCust.SelectedItems[0].SubItems[4].Text);
                int tempPaidBill = Int32.Parse(lstCust.SelectedItems[0].SubItems[5].Text);
                int tempDueBill = Int32.Parse(lstCust.SelectedItems[0].SubItems[6].Text);
                cust_id = temp;
                acc_id = tempAccID;
                grandTotal = tempGrandTotal;
                paidbill = tempPaidBill;
                duebill = tempDueBill;
            }
            grandTotal += total;
            paidbill += amtReceived;
            duebill = (grandTotal - paidbill);

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            SqlCommand cmd = new SqlCommand("update Account set Total_bill = " + grandTotal + ",a_date = '" + DateTime.Now + "',paid_bill =" + paidbill + ",due_bill = '" + duebill + "'  where A_id = (select a_id from Customer where C_id = " + cust_id + " )", con);
            cmd.ExecuteNonQuery();
            con.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (lstReceipt.Items.Count <= 0)
            {
                MessageBox.Show("Please add something to the list to continue", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }

            else if (txcust.Text == "")
            {
                MessageBox.Show("Please Select Customer Name to continue", "Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            }
            else if (MessageBox.Show("Please verify before updating record!! ",
                     "Validation",
                     MessageBoxButtons.YesNo,
                     MessageBoxIcon.Question) == DialogResult.Yes)
            {
                updateRecord(grandtotal, Int32.Parse(txtReceivedAmount.Text));
                listViewCustomer();
                updateQuantity();
                listViewStock();

                MessageBox.Show("Record Updated successfully!! ",
                "Successful",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            }
        }

        int grandtotal;
        string Pname;
        string Pcolor;
        string pCategory;
        string ppWats;
        string pRemStock = "0";
        public void updateQuantity()
        {
            if (listStock.SelectedItems.Count > 0)
            {
                string tempPname = (listStock.SelectedItems[0].SubItems[1].Text);
                string tempPcolor = (listStock.SelectedItems[0].SubItems[3].Text);
                string temppCategory = (listStock.SelectedItems[0].SubItems[6].Text);
                string temppRemStock = (listStock.SelectedItems[0].SubItems[4].Text);
                string temppWats = (listStock.SelectedItems[0].SubItems[5].Text);

                Pname = tempPname;
                Pcolor = tempPcolor;
                pCategory = temppCategory;
                ppWats = temppWats;
                pRemStock = temppRemStock;
            }
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                int qty = Int32.Parse(txtQuantity.Text);
                SqlCommand cmd = new SqlCommand("update stock set ST_quantity = st_quantity - " + qty + "" +
                    " where Comapany_Name = '" + Pname + "' and Color = '" + Pcolor + "'" +
                    " and ST_Category = '" + pCategory + "' and Watt = '" + ppWats + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }
        public void insertReceipt(string pname, string pColor, string ptype, string pWatts)
        {
            if (listStock.SelectedItems.Count > 0)
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();
                // int qty = Int32.Parse(txtQty.Text);
                SqlCommand cmd = new SqlCommand("insert into manageList values('" + pname + "','" + pColor + "','" + ptype + "','" + pWatts + "',1,2,3)", con);
                cmd.ExecuteNonQuery();
                con.Close();
            }
            else
                MessageBox.Show("sht");
        }
        #endregion

        #region ListviewMethods
        public void listViewCustomer()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            lstCust.Items.Clear();
            SqlCommand cmd = new SqlCommand("SELECT Customer.c_id, Customer.Name,Account.a_id, Account.A_date,Account.Total_bill,Account.Paid_bill ,Account.Due_bill FROM Account INNER JOIN Customer ON Customer.A_id = Account.A_id; ", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetSqlDateTime(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(5).ToString());
                lv.SubItems.Add(rd.GetInt32(6).ToString());
                // lv.SubItems.Add(rd.GetInt32(7).ToString());
                lstCust.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();
        }

        public void listViewStock()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listStock.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from stock", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(10).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());

                listStock.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewStocksearch()
        {
            //listStock.Columns[0].AutoResize(ColumnHeaderAutoResizeStyle.ColumnContent);
            //hjjjh

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listStock.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Stock where Comapany_Name like'" + txtSearchbox.Text + "%'", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());
                //lv.SubItems.Add(rd.GetString(8).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());
                lv.SubItems.Add(rd.GetInt32(10).ToString());
                //


                //   lv.SubItems.Add(rd.GetInt32(5).ToString());





                listStock.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }

        public void listViewAccountInfo()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            lstCust.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Account", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem();
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lstCust.Items.Add(lv);
            }
            rd.Close();
            cmd.Dispose();
        }
        #endregion

        #region mouseClickEvents
        private void lstCust_MouseClick(object sender, MouseEventArgs e)
        {
            string custname = lstCust.SelectedItems[0].SubItems[1].Text;
            gbCust.Hide();
            gpReceipt.Show();
            linkLabel3.Text = "Show Customer list";
            txcust.Text = custname;
        }

        int x = 1;
        static public string tempForSelectedItem;
        private void listStock_MouseClick(object sender, MouseEventArgs e)
        {
            if (txcust.Text == "")
            {
                MessageBox.Show("Please Select Customer Name to continue", "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
            else
            {
                if (Int32.Parse(listStock.SelectedItems[0].SubItems[4].Text) <= 100 &&
                    Int32.Parse(listStock.SelectedItems[0].SubItems[4].Text) > 0)
                {
                    MessageBox.Show("Items left in this stock " + listStock.SelectedItems[0].SubItems[4].Text + "\n\nPlease Update Stock", "Warning",
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                if (Int32.Parse(listStock.SelectedItems[0].SubItems[4].Text) <= 0)
                {
                    MessageBox.Show("Out of stock.. ", "Warning!",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    pnlAddQty.Show();
                    int price = Int32.Parse(listStock.SelectedItems[0].SubItems[2].Text);

                    tempForSelectedItem = listStock.SelectedItems[0].SubItems[2].Text;
                    ListViewItem lv = new ListViewItem(x++.ToString());
                    lv.SubItems.Add(listStock.SelectedItems[0].SubItems[1].Text);
                    lv.SubItems.Add(listStock.SelectedItems[0].SubItems[3].Text);
                    lv.SubItems.Add(listStock.SelectedItems[0].SubItems[6].Text);
                    lv.SubItems.Add(listStock.SelectedItems[0].SubItems[5].Text);
                    lv.SubItems.Add(listStock.SelectedItems[0].SubItems[2].Text);
                    //lv.SubItems.Add(addQtyForm.qty);
                    lstReceipt.Items.Add(lv);
                    txtQuantity.Text = "0";
                    // MessageBox.Show(tempForSelectedItem);

                    txtTotalBill.Text = cmbPrice.Text;
                }
            }
        }
        private void linkLabel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (linkLabel1.Text == "Click me ...")
            {
                linkLabel1.Text = "Hide";
                gpNote.Show();
            }
            else
            {
                linkLabel1.Text = "Click me ...";
                gpNote.Hide();
            }
        }

        private void linkLabel3_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            listViewStock();
            if (!gbCust.Visible)
            {
                linkLabel3.Text = "Hide Customer list";
                gbCust.Show();
                gpReceipt.Hide();
            }
            else
            {
                lstReceipt.Items.Clear();
                txtgrandtotal.Text = "0";
                txtQuantity.Text = "0";
                txtReceivedAmount.Text = "0";
                listQty.Items.Clear();
                linkLabel3.Text = "Show Customer list";
                gbCust.Hide();
                gpReceipt.Show();
            }
        }
        #endregion     
        private void addOrderForm_Load(object sender, EventArgs e)
        {
            groupBox1.Hide();
            pnlAddQty.Hide();
            offnouse.Hide();
            linkLabel1.Text = "Click me ...";
            gpNote.Hide();
            gbCust.Hide();
            listViewCustomer();
            listViewStock();
        }

        private void btnDiscard_Click(object sender, EventArgs e)
        {
            lstReceipt.Items.Clear();
            listQty.Items.Clear();
            txtQuantity.Text = "0";
        }

        private void lstReceipt_MouseClick(object sender, MouseEventArgs e)
        {
           //lstReceipt.SelectedItems.Remove();
        }

        private void btnremove_Click(object sender, EventArgs e)
        {
            if (lstReceipt.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Receipt Empty ", "Warning!",
                       MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
                lstReceipt.SelectedItems[0].Remove();
        }

        private void txtSearchbox_TextChanged(object sender, EventArgs e)
        {
            listViewStocksearch();
        }
    }
}