﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;

namespace RoshanGharProject
{
    public partial class afterLoginForm : Form
    {
        string currentBtn; //using it for keeping track of which button is selected

        public string conString = "Data Source=NAUMANAKRAM\\SQLEXPRESS;" +
                                    "Initial Catalog = db_RoshanGharFinal; " +
                                    "Integrated Security = True";
        public afterLoginForm()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm alf = new LoginForm();
            alf.Show();
        } //logout button
        //Buttons
        private void btnCustomers_Click(object sender, EventArgs e)
        {
            pnlUpDateAccount.Hide();
            btnAddStock.Hide();
            pnlAddBtn.Show();
            currentBtn = btnCustomers.Text;
            pictureBox2.Show();
            label.Show();
            label.Text = "Customers";
            pictureBox1.Hide();
            listViewCustomer();
            listView1.Show();
           // pnlAddBtn.Hide();

            txtSearchBox.Show();
        }

        private void afterLoginForm_Load(object sender, EventArgs e)
        {
            pnlUpDateAccount.Hide();
            btnAddStock.Hide();
            pnlAddBtn.Hide();
            pictureBox2.Hide();
            timer1.Start();
            lbldate.Text = DateTime.Now.ToLongDateString();
            lbltime.Text = DateTime.Now.ToLongTimeString();
            label.Hide();
            listView1.Hide();
            lbsearchl.Hide();
            txtSearchBox.Hide();
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            pnlUpDateAccount.Hide();
            btnAddStock.Hide();
            pnlAddBtn.Hide() ;
            currentBtn = btnSuppliers.Text;
            pictureBox2.Show();
            listViewSupplier();
            listView1.Show();
            label.Text = "Suppliers";
            label.Show();
            pictureBox1.Hide();
            lbsearchl.Show();
            txtSearchBox.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            pnlUpDateAccount.Hide();
            btnAddStock.Show();
            pnlAddBtn.Hide();
            currentBtn = button3.Text;
            pictureBox2.Show();
            pictureBox1.Hide();
            listView1.Show();
            listViewStock();
            label.Text = "Stock";
            label.Show();
            lbsearchl.Show();
            txtSearchBox.Show();
        }


        private void btnAccounts_Click(object sender, EventArgs e)
        {
            pnlUpDateAccount.Show();
            btnAddStock.Hide();
            pnlAddBtn.Hide();
            currentBtn = btnAccounts.Text;
            pictureBox2.Show();
            listViewAccounts();
            listView1.Show();
            label.Text = "Accounts";
            label.Show();
            pictureBox1.Hide();
            lbsearchl.Show();
            txtSearchBox.Show();
        }

        //for date to keep running
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Start();
            lbltime.Text = DateTime.Now.ToLongTimeString();
        }
        
        public void listViewAccountsseaarch()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("CustomerID", 75);
            listView1.Columns.Add("Customer Name", 100);
            listView1.Columns.Add("Account Number", 75);
            listView1.Columns.Add("Date", 100);
            listView1.Columns.Add("total bill", 100);
            listView1.Columns.Add("paid bill", 100);
            listView1.Columns.Add("DueBll bill", 100);

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("SELECT Customer.c_id, Customer.Name,Account.a_id, Account.A_date,Account.Total_bill,Account.Paid_bill ,Account.Due_bill FROM Account INNER JOIN Customer ON Customer.A_id = Account.A_id where customer.name like '%"+txtSearchBox.Text+"%'; ", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetSqlDateTime(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(5).ToString());
                lv.SubItems.Add(rd.GetInt32(6).ToString());
                // lv.SubItems.Add(rd.GetInt32(7).ToString());
                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewCustomerseaarch()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 75);
            listView1.Columns.Add("Customer Name", 100);
            listView1.Columns.Add("Address", 150);
            listView1.Columns.Add("Cnic", 150);
            listView1.Columns.Add("Account Id", 75);

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Customer where Name like '" + txtSearchBox.Text + "%'", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetString(2).ToString());
                lv.SubItems.Add(rd.GetString(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewSuppliersearch()
        {
            //listView1.Columns[0].AutoResize();
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 75);
            listView1.Columns.Add("Supplier Name", 75);
            listView1.Columns.Add("Address", 150);
            listView1.Columns.Add("Cnic", 100);
            listView1.Columns.Add("Company First Name", 100);


            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Supplier where name like'" + txtSearchBox.Text + "%'", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetString(2).ToString());
                lv.SubItems.Add(rd.GetString(3).ToString());
                lv.SubItems.Add(rd.GetString(4).ToString());

                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewStocksearch()
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("select * from Stock where Comapany_Name like'" + txtSearchBox.Text + "%'", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(5).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());
                lv.SubItems.Add(rd.GetString(8).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());

                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }

        public void listViewAccounts()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("CustomerID", 75);
            listView1.Columns.Add("Customer Name", 100);
            listView1.Columns.Add("Account Number", 75);
            listView1.Columns.Add("Date" , 100);
            listView1.Columns.Add("total bill", 100);
            listView1.Columns.Add("paid bill", 100);
            listView1.Columns.Add("DueBll bill", 100);
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("SELECT Customer.c_id, Customer.Name,Account.a_id, Account.A_date,Account.Total_bill,Account.Paid_bill ,Account.Due_bill FROM Account INNER JOIN Customer ON Customer.A_id = Account.A_id; ", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetSqlDateTime(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(5).ToString());
                lv.SubItems.Add(rd.GetInt32(6).ToString());
                // lv.SubItems.Add(rd.GetInt32(7).ToString());
                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();
        }


        public void listViewCustomer()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 75);
            listView1.Columns.Add("Customer Name", 100);
            listView1.Columns.Add("Address", 150);
            listView1.Columns.Add("Cnic", 150);
            listView1.Columns.Add("Account Id", 75);
            
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from customer", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetString(2).ToString());
                lv.SubItems.Add(rd.GetString(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewSupplier()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 75);
            listView1.Columns.Add("Supplier Name", 75);
            listView1.Columns.Add("Address", 150);
            listView1.Columns.Add("Cnic", 100);
            listView1.Columns.Add("Company Name", 100);
           

            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from Supplier", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetString(2).ToString());
                lv.SubItems.Add(rd.GetString(3).ToString());
                lv.SubItems.Add(rd.GetString(4).ToString());

                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }
        public void listViewStock()
        {
            listView1.Columns.Clear();
            listView1.Columns.Add("ID", 75);
            listView1.Columns.Add("Company Name", 75);
            listView1.Columns.Add("Unit Price", 75);
            listView1.Columns.Add("Total Price", 75);
            listView1.Columns.Add("Quantity", 75);
            listView1.Columns.Add("Supplier ID", 75);
            listView1.Columns.Add("Color", 75);
            listView1.Columns.Add("Category",75);
            listView1.Columns.Add("Type", 75);
            listView1.Columns.Add("Watt", 75);


            SqlConnection con = new SqlConnection(conString);
            con.Open();
            listView1.Items.Clear();
            SqlCommand cmd = new SqlCommand("Select * from stock", con);
            SqlDataReader rd;
            rd = cmd.ExecuteReader();
            while (rd.Read())
            {
                ListViewItem lv = new ListViewItem(rd.GetInt32(0).ToString());
                lv.SubItems.Add(rd.GetString(1).ToString());
                lv.SubItems.Add(rd.GetInt32(2).ToString());
                lv.SubItems.Add(rd.GetInt32(3).ToString());
                lv.SubItems.Add(rd.GetInt32(4).ToString());
                lv.SubItems.Add(rd.GetInt32(5).ToString());
                lv.SubItems.Add(rd.GetString(6).ToString());
                lv.SubItems.Add(rd.GetString(7).ToString());
                lv.SubItems.Add(rd.GetString(8).ToString());
                lv.SubItems.Add(rd.GetString(9).ToString());

                listView1.Items.Add(lv);

            }
            rd.Close();
            cmd.Dispose();

        }

        private void txtSearchBox_TextChanged(object sender, EventArgs e)
        {
            if (currentBtn == btnAccounts.Text)
                listViewAccountsseaarch();
            else if (currentBtn == btnCustomers.Text)
                listViewCustomerseaarch();
            else if (currentBtn == btnSuppliers.Text)
                listViewSuppliersearch();
            else if (currentBtn == button3.Text)
                listViewStocksearch();
        }

        private void btnOrders_Click(object sender, EventArgs e)
        {
            pnlUpDateAccount.Hide();
            pnlAddBtn.Hide();
            this.Hide();
            addOrderForm ad = new addOrderForm();
            ad.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddUpdateForm aaa = new AddUpdateForm();
            aaa.Show();
        }

        private void lbsearchl_Click(object sender, EventArgs e)
        {

        }

        private void btnAddStock_Click(object sender, EventArgs e)
        {
            this.Hide();
            AddItemsForm a = new AddItemsForm();
            a.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
        int a_id;
        
        private void btnUpdateAccount_Click(object sender, EventArgs e)
        {
            if(listView1.SelectedItems.Count <= 0)
            {
                MessageBox.Show("Please Select a customer from the list!", "Error",
              MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                    a_id = Int32.Parse(listView1.SelectedItems[0].SubItems[2].Text);
                    txtCust.Text = listView1.SelectedItems[0].SubItems[1].Text;
                    int amtReceived = Int32.Parse(txtAmtReceived.Text);
                    SqlConnection con = new SqlConnection(conString);
                    con.Open();
                    SqlCommand cmd = new SqlCommand("update Account set Paid_bill = Paid_bill + " + amtReceived + " , Due_bill = Due_bill - " + amtReceived + " where a_id = " + a_id + "; ", con);
                    cmd.ExecuteNonQuery();
                    listViewAccounts();   
            }
            
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems[0].SubItems[6].Text == "0")
            {
                MessageBox.Show("No Due Balance!", "Error",
          MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                txtCust.Text = listView1.SelectedItems[0].SubItems[1].Text;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);
            con.Open();
            //cmd.CommandText = "SELECT COUNT(*) FROM table_name";
            
            SqlCommand cmd = new SqlCommand("select count(*)  from Account", con);
            Int32 count = (Int32)cmd.ExecuteScalar();
            MessageBox.Show("i get " + count.ToString());
           // cmd.ExecuteNonQuery();
        }
    }
  
}


