﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RoshanGharProject
{
   
    public partial class addQtyForm : Form
    {
        static public string qty;
        static public bool btnstate = true;
        public addQtyForm()
        {
            InitializeComponent();
        }
        public static string txtQtyl = "";
        public void btnAdd_Click(object sender, EventArgs e)
        {
            addOrderForm aa = new addOrderForm();
           // string qty = txtQty.Text;
            txtQtyl = txtQty.Text;
           // MessageBox.Show(txtQtyl);
            MessageBox.Show(addQtyForm.txtQtyl);
            ListViewItem lv2 = new ListViewItem();
            lv2.SubItems.Add(txtQty.Text);
            aa.listQty.Items.Add(lv2);
            // aa.addToList();
            //aa.lstReceipt.Items.Add(addOrderForm.lv);
            //aa.lstReceipt.Show();
            //ListViewItem lv = new ListViewItem();
            //lv.SubItems.Add(txtQty.Text);
            //aa.listQty.Items.Add(lv);


            this.Hide();
        }
    }
}
